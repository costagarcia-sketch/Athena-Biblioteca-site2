# Biblioteca Escolar - Sistema de Gerenciamento de Biblioteca

## Visão Geral
Sistema completo de gerenciamento de biblioteca escolar com autenticação diferenciada para administradores e alunos.

## Funcionalidades Principais

### Para Administradores
- **Dashboard**: Estatísticas em tempo real (total de livros, empréstimos ativos, livros atrasados, reservas)
- **Gerenciamento de Livros**: CRUD completo com busca, categorização e controle de disponibilidade
- **Gerenciamento de Empréstimos**: Registrar empréstimos, controlar devoluções e prazos
- **Movimentação**: Histórico completo de todas as movimentações da biblioteca
- **Cobranças**: Lista de empréstimos atrasados com detalhes para cobrança

### Para Alunos
- **Catálogo**: Navegação completa por todos os livros com busca e filtros
- **Reservas**: Reservar livros indisponíveis e acompanhar status
- **Meus Empréstimos**: Ver empréstimos ativos com prazos de devolução
- **Avaliações**: Avaliar e comentar sobre livros lidos

## Tecnologias Utilizadas

### Frontend
- React com TypeScript
- Wouter para roteamento
- TanStack Query para gerenciamento de estado
- Shadcn UI + Tailwind CSS para interface
- React Hook Form + Zod para validação de formulários

### Backend
- Express.js
- PostgreSQL (Neon)
- Drizzle ORM
- Replit Auth (OpenID Connect)
- Validação com Zod

## Estrutura do Banco de Dados

### Tabelas Principais
- **users**: Usuários com roles (admin/student)
- **books**: Catálogo de livros
- **loans**: Empréstimos de livros
- **reservations**: Reservas de livros indisponíveis
- **reviews**: Avaliações e comentários dos alunos
- **sessions**: Sessões de autenticação

## Autenticação e Autorização

### Sistema de Roles
- **Admin**: Primeiro usuário a fazer login OU usuários com email na variável `ADMIN_EMAILS`
- **Student**: Todos os outros usuários (padrão)

### Configuração de Admin
Para adicionar emails de admin, defina a variável de ambiente:
```
ADMIN_EMAILS=admin@escola.com,diretor@escola.com
```

## Fluxo de Autenticação
1. Usuário acessa a landing page
2. Clica em "Entrar"
3. É redirecionado para Replit Auth (suporta Google, GitHub, email)
4. Após login, é redirecionado de acordo com seu role:
   - Admin → Dashboard administrativo
   - Student → Catálogo de livros

## Funcionalidades Implementadas

### Lógica de Negócio
- **Detecção automática de atrasos**: Sistema verifica e atualiza status de empréstimos atrasados
- **Controle de disponibilidade**: Quantidade disponível atualizada automaticamente ao emprestar/devolver
- **Validação de reservas**: Só permite reservar livros indisponíveis
- **Avaliações com média**: Cálculo automático de rating médio por livro

### Interface do Usuário
- Design responsivo para mobile e desktop
- Estados de loading com skeletons
- Estados vazios informativos
- Mensagens de erro e sucesso com toasts
- Badges coloridos para status (disponível, emprestado, atrasado)
- Busca em tempo real
- Formulários com validação completa

## Estrutura do Projeto

```
/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── pages/         # Páginas da aplicação
│   │   │   ├── admin/    # Páginas administrativas
│   │   │   └── student/  # Páginas dos alunos
│   │   ├── hooks/        # Custom hooks
│   │   └── lib/          # Utilitários
│   └── index.html
├── server/                # Backend Express
│   ├── db.ts            # Configuração do banco
│   ├── storage.ts       # Interface de armazenamento
│   ├── routes.ts        # Rotas da API
│   └── replitAuth.ts    # Configuração de autenticação
├── shared/
│   └── schema.ts        # Schemas compartilhados
└── design_guidelines.md # Guia de design da aplicação
```

## API Endpoints

### Autenticação
- `GET /api/auth/user` - Dados do usuário atual
- `GET /api/login` - Iniciar login
- `GET /api/logout` - Fazer logout
- `GET /api/callback` - Callback do OIDC

### Admin (requer autenticação + role admin)
- `GET /api/admin/stats` - Estatísticas do dashboard
- `GET /api/admin/books` - Listar todos os livros
- `POST /api/admin/books` - Criar livro
- `PATCH /api/admin/books/:id` - Atualizar livro
- `DELETE /api/admin/books/:id` - Remover livro
- `GET /api/admin/loans` - Listar todos os empréstimos
- `POST /api/admin/loans` - Criar empréstimo
- `PATCH /api/admin/loans/:id/return` - Registrar devolução
- `GET /api/admin/students` - Listar alunos

### Student (requer autenticação)
- `GET /api/books` - Catálogo de livros com avaliações
- `GET /api/loans` - Empréstimos do usuário
- `GET /api/reservations` - Reservas do usuário
- `POST /api/reservations` - Criar reserva
- `DELETE /api/reservations/:id` - Cancelar reserva
- `POST /api/reviews` - Criar avaliação

## Como Rodar

1. O sistema já está configurado e rodando
2. Acesse a URL da aplicação
3. Faça login com Replit Auth
4. O primeiro usuário a fazer login será automaticamente admin

## Desenvolvimento Futuro

Funcionalidades que podem ser adicionadas:
- Notificações por email para prazos de devolução
- Relatórios detalhados de uso
- Sistema de multas automáticas
- Busca avançada com filtros
- Renovação de empréstimos online
- Upload de capas de livros
- Sistema de categorias e tags
- Histórico de leitura dos alunos

## Observações Importantes

### Variáveis de Ambiente
- `DATABASE_URL`: Conexão com PostgreSQL (configurado automaticamente)
- `SESSION_SECRET`: Secret para sessões (configurado automaticamente)
- `ADMIN_EMAILS`: Lista de emails que devem ter acesso admin (opcional)
- `REPL_ID`: ID do Repl para OIDC (configurado automaticamente)

### Segurança
- Todas as rotas de admin verificam role do usuário
- Sessões armazenadas no PostgreSQL
- Cookies seguros em produção
- Validação de dados com Zod em todas as entradas

## Arquitetura Recente

### 13 de Novembro de 2025
- Implementação completa do sistema MVP
- Integração com Replit Auth para autenticação
- Sistema de roles com primeiro usuário como admin
- Todas as funcionalidades principais implementadas
- Design responsivo seguindo material design educacional
