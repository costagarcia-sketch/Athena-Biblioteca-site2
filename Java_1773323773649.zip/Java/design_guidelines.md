# Design Guidelines: Sistema de Biblioteca Escolar

## Design Approach
**System-Based Approach**: Material Design adapted for educational productivity
- Justification: Information-dense application requiring clear data hierarchy, efficient workflows, and familiar patterns for school environment
- Focus on usability, accessibility, and data organization over visual experimentation

## Typography System

**Font Family**: Inter (Google Fonts) for all text
- Primary: Inter 400 (body), 500 (emphasis), 600 (headings)
- Monospace: JetBrains Mono 400 for ISBN codes and IDs

**Hierarchy**:
- Page Titles: text-3xl font-semibold (Admin dashboard headers, section titles)
- Card Headers: text-xl font-semibold (Book titles, panel headers)
- Subsections: text-lg font-medium (Category labels, table headers)
- Body Text: text-base (Descriptions, form labels, table data)
- Supporting Text: text-sm (Timestamps, metadata, helper text)
- Captions: text-xs (Status badges, footnotes)

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12
- Component padding: p-4 to p-6
- Section spacing: space-y-6 to space-y-8
- Card gaps: gap-4 to gap-6
- Page margins: px-4 md:px-8

**Grid Structure**:
- Admin Dashboard: 2-column layout (sidebar 280px + main content)
- Student Interface: Single column with max-w-6xl container
- Book Catalog: 3-column grid on desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Data Tables: Full-width responsive with horizontal scroll on mobile

## Component Library

### Navigation
**Admin Sidebar**:
- Fixed left navigation with logo at top
- Icon + label menu items (Dashboard, Livros, Empréstimos, Movimentação, Cobranças)
- Active state indicator with border accent
- User profile section at bottom with logout

**Student Header**:
- Horizontal navigation bar with logo left
- Menu items: Catálogo, Minhas Reservas, Meus Empréstimos, Perfil
- Search bar integrated in header (w-full max-w-md)
- User avatar with dropdown menu right-aligned

### Authentication
**Login Page**:
- Centered card (max-w-md) on minimal background
- Role selection tabs (Administrador/Aluno) at top of card
- Replit Auth integration button prominent
- School logo and name above card

### Data Display
**Book Cards** (Student View):
- Image thumbnail (aspect-ratio-[2/3], w-full)
- Title (text-lg font-semibold, 2-line clamp)
- Author (text-sm)
- Availability badge (chip component, top-right overlay on image)
- Reserve button (w-full, prominent)
- Rating display (stars + count)

**Data Tables** (Admin View):
- Sticky header row with sort indicators
- Alternating row backgrounds for readability
- Action buttons right-aligned in each row
- Status badges (color-coded: Disponível, Emprestado, Atrasado, Reservado)
- Pagination controls at bottom

**Dashboard Cards**:
- Statistical cards in 4-column grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Large number (text-4xl font-bold) with label below
- Icon in top-right corner
- Subtle elevation (shadow-sm)

### Forms
**Book Registration** (Admin):
- 2-column layout for inputs (grid-cols-1 md:grid-cols-2)
- Clear labels above inputs
- Helper text below inputs (text-sm)
- Image upload with preview
- Submit button full-width on mobile, right-aligned on desktop

**Loan Management**:
- Search/select student component
- Search/select book component
- Date picker for return date
- Notes/observations textarea
- Visual summary before confirmation

**Feedback Form** (Student):
- Star rating selector (large, interactive)
- Textarea for written review
- Photo upload option
- Public/private toggle

### Status Indicators
**Loan Status Timeline**:
- Horizontal stepper showing: Reservado → Emprestado → Devolvido
- Current step highlighted
- Date stamps under each step

**Overdue Warnings**:
- Alert banner (full-width) for overdue items
- Icon + message + action button
- Severity levels (warning yellow border, urgent red border)

### Modals & Overlays
- Standard modal with header, body, footer structure
- Confirmation dialogs for destructive actions
- Max-w-2xl centered overlay
- Backdrop with blur effect

## Images

**Login Page Hero**: 
- Background image of library shelves with books (full viewport height, subtle overlay for text legibility)

**Admin Dashboard**: 
- No hero image needed (functional interface)
- Book placeholder images in catalog (use generic book cover icons until uploaded)

**Student Catalog**: 
- No full hero, but prominent search bar section with subtle background pattern
- Book cover images are essential (aspect-ratio-[2/3], object-cover)

**Empty States**: 
- Illustration for "No books borrowed yet", "No reservations", etc. (max-w-xs mx-auto)

## Accessibility
- Minimum touch target size: 44x44px for all interactive elements
- Form inputs with associated labels (not just placeholders)
- ARIA labels for icon-only buttons
- Keyboard navigation support for all interactions
- Error states with both color and icon indicators
- Skip navigation link for keyboard users

## Animations
Minimal, functional animations only:
- Page transitions: Simple fade (200ms)
- Dropdown menus: Slide down (150ms)
- Modal entry: Scale + fade (200ms)
- No scroll-triggered animations
- No complex hero animations