import { BookOpen, Library, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <BookOpen className="h-6 w-6 text-primary" />
              <span className="text-lg font-semibold">Biblioteca Escolar</span>
            </div>
            <Button
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-login"
            >
              Entrar
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="py-20 md:py-32">
          <div className="container mx-auto px-4 md:px-8">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">
                Bem-vindo à Biblioteca Escolar
              </h1>
              <p className="text-xl text-muted-foreground">
                Sistema completo de gerenciamento de biblioteca para
                administradores e alunos
              </p>
              <div className="pt-4">
                <Button
                  size="lg"
                  onClick={() => window.location.href = "/api/login"}
                  data-testid="button-login-hero"
                >
                  Acessar Sistema
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/50">
          <div className="container mx-auto px-4 md:px-8">
            <h2 className="text-3xl font-semibold text-center mb-12">
              Funcionalidades
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <Library className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Catálogo Completo</h3>
                    <p className="text-muted-foreground">
                      Navegue por todo o acervo da biblioteca com facilidade
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <BookOpen className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Empréstimos Online</h3>
                    <p className="text-muted-foreground">
                      Reserve e acompanhe seus empréstimos pelo sistema
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Gestão Eficiente</h3>
                    <p className="text-muted-foreground">
                      Administradores podem gerenciar todo o acervo
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <Star className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Avaliações</h3>
                    <p className="text-muted-foreground">
                      Compartilhe sua opinião sobre os livros que leu
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <BookOpen className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Reservas</h3>
                    <p className="text-muted-foreground">
                      Reserve livros indisponíveis e seja avisado
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <Library className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold">Controle de Prazos</h3>
                    <p className="text-muted-foreground">
                      Acompanhe prazos de devolução e evite atrasos
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
