import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, Star, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { Book, Review, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

interface BookWithReviews extends Book {
  reviews: (Review & { user: User })[];
  averageRating: number;
}

export default function Catalog() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBook, setSelectedBook] = useState<BookWithReviews | null>(null);
  const { toast } = useToast();

  const { data: books, isLoading } = useQuery<BookWithReviews[]>({
    queryKey: ["/api/books"],
  });

  const reserveMutation = useMutation({
    mutationFn: async (bookId: string) => {
      await apiRequest("POST", "/api/reservations", { bookId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      setSelectedBook(null);
      toast({
        title: "Sucesso",
        description: "Livro reservado com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Fazendo login novamente...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: error.message || "Não foi possível reservar o livro.",
        variant: "destructive",
      });
    },
  });

  const filteredBooks = books?.filter(
    (book) =>
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderStars = (rating: number) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating
                ? "fill-primary text-primary"
                : "fill-muted text-muted"
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Catálogo de Livros</h1>
        <p className="text-muted-foreground">
          Navegue pelo acervo completo da biblioteca
        </p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por título, autor ou categoria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-catalog"
            />
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-48 w-full rounded-md" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredBooks && filteredBooks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map((book) => (
            <Card
              key={book.id}
              className="hover-elevate cursor-pointer"
              onClick={() => setSelectedBook(book)}
              data-testid={`card-book-${book.id}`}
            >
              <CardHeader className="p-0">
                <div className="relative aspect-[2/3] w-full overflow-hidden rounded-t-md bg-muted">
                  {book.coverImage ? (
                    <img
                      src={book.coverImage}
                      alt={book.title}
                      className="object-cover w-full h-full"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <BookOpen className="h-16 w-16 text-muted-foreground" />
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    <Badge variant={book.availableQuantity > 0 ? "default" : "destructive"}>
                      {book.availableQuantity > 0 ? "Disponível" : "Indisponível"}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-2">
                <CardTitle className="line-clamp-2">{book.title}</CardTitle>
                <p className="text-sm text-muted-foreground">{book.author}</p>
                {book.category && (
                  <Badge variant="secondary">{book.category}</Badge>
                )}
                {book.averageRating > 0 && (
                  <div className="flex items-center gap-2">
                    {renderStars(Math.round(book.averageRating))}
                    <span className="text-sm text-muted-foreground">
                      ({book.reviews.length})
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-muted-foreground">
              {searchTerm
                ? "Nenhum livro encontrado com esses critérios."
                : "Nenhum livro disponível no momento."}
            </p>
          </CardContent>
        </Card>
      )}

      <Dialog open={!!selectedBook} onOpenChange={() => setSelectedBook(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedBook && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedBook.title}</DialogTitle>
                <DialogDescription>{selectedBook.author}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex gap-6">
                  <div className="w-32 flex-shrink-0">
                    <div className="aspect-[2/3] w-full overflow-hidden rounded-md bg-muted">
                      {selectedBook.coverImage ? (
                        <img
                          src={selectedBook.coverImage}
                          alt={selectedBook.title}
                          className="object-cover w-full h-full"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <BookOpen className="h-12 w-12 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex-1 space-y-3">
                    <div>
                      <p className="text-sm font-medium">Disponibilidade</p>
                      <Badge
                        variant={
                          selectedBook.availableQuantity > 0 ? "default" : "destructive"
                        }
                      >
                        {selectedBook.availableQuantity}/{selectedBook.totalQuantity} disponível
                      </Badge>
                    </div>
                    {selectedBook.isbn && (
                      <div>
                        <p className="text-sm font-medium">ISBN</p>
                        <p className="text-sm font-mono">{selectedBook.isbn}</p>
                      </div>
                    )}
                    {selectedBook.category && (
                      <div>
                        <p className="text-sm font-medium">Categoria</p>
                        <Badge variant="secondary">{selectedBook.category}</Badge>
                      </div>
                    )}
                    {selectedBook.averageRating > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-1">Avaliação</p>
                        <div className="flex items-center gap-2">
                          {renderStars(Math.round(selectedBook.averageRating))}
                          <span className="text-sm text-muted-foreground">
                            {selectedBook.averageRating.toFixed(1)} ({selectedBook.reviews.length}{" "}
                            avaliações)
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                {selectedBook.description && (
                  <div>
                    <p className="text-sm font-medium mb-2">Descrição</p>
                    <p className="text-sm text-muted-foreground">{selectedBook.description}</p>
                  </div>
                )}
                {selectedBook.reviews.length > 0 && (
                  <div>
                    <p className="text-sm font-medium mb-3">Avaliações</p>
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {selectedBook.reviews.map((review) => (
                        <div key={review.id} className="p-3 rounded-md border">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="text-sm font-medium">
                                {review.user.firstName || review.user.email}
                              </p>
                              {renderStars(review.rating)}
                            </div>
                          </div>
                          {review.comment && (
                            <p className="text-sm text-muted-foreground">{review.comment}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setSelectedBook(null)}
                  data-testid="button-close-book"
                >
                  Fechar
                </Button>
                {selectedBook.availableQuantity === 0 && (
                  <Button
                    onClick={() => reserveMutation.mutate(selectedBook.id)}
                    disabled={reserveMutation.isPending}
                    data-testid="button-reserve-book"
                  >
                    {reserveMutation.isPending ? "Reservando..." : "Reservar"}
                  </Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
