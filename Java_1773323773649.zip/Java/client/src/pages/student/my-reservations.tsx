import { useQuery, useMutation } from "@tanstack/react-query";
import { X, BookMarked } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Reservation, Book } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

interface ReservationWithBook extends Reservation {
  book: Book;
}

export default function MyReservations() {
  const { toast } = useToast();

  const { data: reservations, isLoading } = useQuery<ReservationWithBook[]>({
    queryKey: ["/api/reservations"],
  });

  const cancelMutation = useMutation({
    mutationFn: async (reservationId: string) => {
      await apiRequest("DELETE", `/api/reservations/${reservationId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      toast({
        title: "Sucesso",
        description: "Reserva cancelada com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Fazendo login novamente...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Não foi possível cancelar a reserva.",
        variant: "destructive",
      });
    },
  });

  const pendingReservations = reservations?.filter(r => r.status === "pending");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Minhas Reservas</h1>
        <p className="text-muted-foreground">
          Acompanhe suas reservas de livros
        </p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : pendingReservations && pendingReservations.length > 0 ? (
        <div className="space-y-4">
          {pendingReservations.map((reservation) => (
            <Card key={reservation.id} data-testid={`reservation-${reservation.id}`}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <BookMarked className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium">{reservation.book.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {reservation.book.author}
                        </p>
                      </div>
                      <Badge variant="secondary">Pendente</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Reservado em: {reservation.reservationDate}
                    </p>
                    <p className="text-sm">
                      Você será notificado quando o livro estiver disponível.
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => cancelMutation.mutate(reservation.id)}
                    disabled={cancelMutation.isPending}
                    data-testid={`button-cancel-${reservation.id}`}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center space-y-4">
            <div className="flex justify-center">
              <div className="h-16 w-16 rounded-md bg-muted flex items-center justify-center">
                <BookMarked className="h-8 w-8 text-muted-foreground" />
              </div>
            </div>
            <div>
              <p className="font-medium mb-1">Nenhuma reserva ativa</p>
              <p className="text-sm text-muted-foreground">
                Você pode reservar livros indisponíveis no catálogo.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
