import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { BookOpen, Star, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertReviewSchema } from "@shared/schema";
import type { Loan, Book } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { z } from "zod";

interface LoanWithBook extends Loan {
  book: Book;
}

const reviewFormSchema = insertReviewSchema.extend({
  rating: z.number().min(1).max(5),
});

type ReviewFormData = z.infer<typeof reviewFormSchema>;

export default function MyLoans() {
  const [reviewingBook, setReviewingBook] = useState<Book | null>(null);
  const { toast } = useToast();

  const { data: loans, isLoading } = useQuery<LoanWithBook[]>({
    queryKey: ["/api/loans"],
  });

  const form = useForm<ReviewFormData>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      bookId: "",
      userId: "",
      rating: 5,
      comment: "",
    },
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: ReviewFormData) => {
      await apiRequest("POST", "/api/reviews", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      setReviewingBook(null);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Avaliação enviada com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Fazendo login novamente...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Não foi possível enviar a avaliação.",
        variant: "destructive",
      });
    },
  });

  const handleReview = (book: Book) => {
    setReviewingBook(book);
    form.setValue("bookId", book.id);
  };

  const handleSubmitReview = (data: ReviewFormData) => {
    reviewMutation.mutate(data);
  };

  const activeLoans = loans?.filter(l => l.status === "active" || l.status === "overdue");
  const returnedLoans = loans?.filter(l => l.status === "returned");

  const getDaysRemaining = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const renderStars = (rating: number, onChange?: (rating: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-5 w-5 ${
              star <= rating
                ? "fill-primary text-primary"
                : "fill-muted text-muted"
            } ${onChange ? "cursor-pointer" : ""}`}
            onClick={() => onChange?.(star)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2">Meus Empréstimos</h1>
        <p className="text-muted-foreground">
          Acompanhe seus empréstimos ativos e histórico
        </p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {activeLoans && activeLoans.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Empréstimos Ativos</h2>
              {activeLoans.map((loan) => {
                const daysRemaining = getDaysRemaining(loan.dueDate);
                const isOverdue = daysRemaining < 0;
                return (
                  <Card key={loan.id} data-testid={`loan-${loan.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <BookOpen className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium">{loan.book.title}</p>
                              <p className="text-sm text-muted-foreground">
                                {loan.book.author}
                              </p>
                            </div>
                            <Badge variant={isOverdue ? "destructive" : "default"}>
                              {isOverdue ? "Atrasado" : "Ativo"}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap gap-4 text-sm">
                            <span className="text-muted-foreground">
                              Empréstimo: {loan.loanDate}
                            </span>
                            <span className="text-muted-foreground">
                              Devolução: {loan.dueDate}
                            </span>
                          </div>
                          <div className="text-sm">
                            {isOverdue ? (
                              <span className="text-destructive font-medium">
                                Atrasado há {Math.abs(daysRemaining)} dia
                                {Math.abs(daysRemaining) !== 1 ? "s" : ""}
                              </span>
                            ) : daysRemaining === 0 ? (
                              <span className="text-destructive font-medium">
                                Devolução hoje
                              </span>
                            ) : daysRemaining === 1 ? (
                              <span className="font-medium">
                                Devolução amanhã
                              </span>
                            ) : (
                              <span>
                                Faltam {daysRemaining} dias para devolução
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {returnedLoans && returnedLoans.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Histórico</h2>
              {returnedLoans.map((loan) => (
                <Card key={loan.id} data-testid={`loan-history-${loan.id}`}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                        <BookOpen className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium">{loan.book.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {loan.book.author}
                            </p>
                          </div>
                          <Badge variant="secondary">Devolvido</Badge>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span>Empréstimo: {loan.loanDate}</span>
                          <span>Devolução: {loan.returnDate}</span>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleReview(loan.book)}
                          data-testid={`button-review-${loan.id}`}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Avaliar Livro
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {(!activeLoans || activeLoans.length === 0) &&
            (!returnedLoans || returnedLoans.length === 0) && (
              <Card>
                <CardContent className="p-12 text-center space-y-4">
                  <div className="flex justify-center">
                    <div className="h-16 w-16 rounded-md bg-muted flex items-center justify-center">
                      <BookOpen className="h-8 w-8 text-muted-foreground" />
                    </div>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Nenhum empréstimo registrado</p>
                    <p className="text-sm text-muted-foreground">
                      Navegue pelo catálogo para encontrar livros disponíveis.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
        </>
      )}

      <Dialog open={!!reviewingBook} onOpenChange={() => setReviewingBook(null)}>
        <DialogContent>
          {reviewingBook && (
            <>
              <DialogHeader>
                <DialogTitle>Avaliar Livro</DialogTitle>
                <DialogDescription>
                  Compartilhe sua opinião sobre {reviewingBook.title}
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmitReview)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Avaliação</FormLabel>
                        <FormControl>
                          <div>
                            {renderStars(field.value, field.onChange)}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="comment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Comentário (opcional)</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            rows={4}
                            placeholder="Compartilhe sua experiência com este livro..."
                            data-testid="input-review-comment"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setReviewingBook(null)}
                      data-testid="button-cancel-review"
                    >
                      Cancelar
                    </Button>
                    <Button
                      type="submit"
                      disabled={reviewMutation.isPending}
                      data-testid="button-submit-review"
                    >
                      {reviewMutation.isPending ? "Enviando..." : "Enviar Avaliação"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
