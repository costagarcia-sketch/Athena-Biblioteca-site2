import { useQuery } from "@tanstack/react-query";
import { AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import type { Loan, Book, User } from "@shared/schema";

interface LoanWithDetails extends Loan {
  book: Book;
  user: User;
}

export default function Charges() {
  const { data: loans, isLoading } = useQuery<LoanWithDetails[]>({
    queryKey: ["/api/admin/loans"],
  });

  const overdueLoans = loans?.filter(loan => loan.status === "overdue");

  const getDaysOverdue = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = today.getTime() - due.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Cobranças e Atrasos</h1>

      {overdueLoans && overdueLoans.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Atenção</AlertTitle>
          <AlertDescription>
            Existem {overdueLoans.length} empréstimo(s) atrasado(s) que requerem atenção.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Estatísticas de Atrasos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-2xl font-bold" data-testid="stat-overdue-total">
                {overdueLoans?.length || 0}
              </div>
              <p className="text-sm text-muted-foreground">
                Empréstimos atrasados
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold" data-testid="stat-overdue-avg">
                {overdueLoans && overdueLoans.length > 0
                  ? Math.round(
                      overdueLoans.reduce((acc, loan) => acc + getDaysOverdue(loan.dueDate), 0) /
                        overdueLoans.length
                    )
                  : 0}
              </div>
              <p className="text-sm text-muted-foreground">
                Dias de atraso médio
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold" data-testid="stat-overdue-max">
                {overdueLoans && overdueLoans.length > 0
                  ? Math.max(...overdueLoans.map(loan => getDaysOverdue(loan.dueDate)))
                  : 0}
              </div>
              <p className="text-sm text-muted-foreground">
                Maior atraso (dias)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Empréstimos Atrasados</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : overdueLoans && overdueLoans.length > 0 ? (
            <div className="space-y-4">
              {overdueLoans.map((loan) => {
                const daysOverdue = getDaysOverdue(loan.dueDate);
                return (
                  <div
                    key={loan.id}
                    className="flex items-start gap-4 p-4 rounded-md border border-destructive/20 bg-destructive/5"
                    data-testid={`overdue-loan-${loan.id}`}
                  >
                    <div className="h-10 w-10 rounded-md bg-destructive/10 flex items-center justify-center flex-shrink-0">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                    </div>
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium">{loan.book.title}</p>
                          <p className="text-sm text-muted-foreground">
                            Emprestado para: {loan.user.firstName || loan.user.email}
                          </p>
                          {loan.user.email && (
                            <p className="text-sm text-muted-foreground">
                              Email: {loan.user.email}
                            </p>
                          )}
                        </div>
                        <Badge variant="destructive">
                          {daysOverdue} dia{daysOverdue !== 1 ? "s" : ""} de atraso
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                        <span>Data empréstimo: {loan.loanDate}</span>
                        <span>Prazo de devolução: {loan.dueDate}</span>
                      </div>
                      {loan.notes && (
                        <p className="text-sm">
                          <span className="font-medium">Observações:</span> {loan.notes}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 text-center">
              <p className="text-muted-foreground">
                Não há empréstimos atrasados no momento.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
