import { useQuery } from "@tanstack/react-query";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import type { Loan, Book, User } from "@shared/schema";

interface LoanWithDetails extends Loan {
  book: Book;
  user: User;
}

export default function Movements() {
  const { data: loans, isLoading } = useQuery<LoanWithDetails[]>({
    queryKey: ["/api/admin/loans"],
  });

  const recentLoans = loans?.slice().sort((a, b) => {
    const dateA = new Date(a.createdAt || "").getTime();
    const dateB = new Date(b.createdAt || "").getTime();
    return dateB - dateA;
  }).slice(0, 20);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Movimentação da Biblioteca</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">
              Total de Movimentações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-total-movements">
              {loans?.length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Empréstimos registrados
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">
              Devoluções Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-pending-returns">
              {loans?.filter(l => l.status === "active" || l.status === "overdue").length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Livros ainda emprestados
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Histórico Recente</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : recentLoans && recentLoans.length > 0 ? (
            <div className="space-y-4">
              {recentLoans.map((loan) => (
                <div
                  key={loan.id}
                  className="flex items-start gap-4 p-4 rounded-md border hover-elevate"
                  data-testid={`movement-${loan.id}`}
                >
                  <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                    {loan.status === "returned" ? (
                      <TrendingDown className="h-5 w-5 text-primary" />
                    ) : (
                      <TrendingUp className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{loan.book.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {loan.user.firstName || loan.user.email}
                        </p>
                      </div>
                      <div className="flex-shrink-0">
                        {loan.status === "returned" ? (
                          <Badge variant="secondary">Devolvido</Badge>
                        ) : loan.status === "overdue" ? (
                          <Badge variant="destructive">Atrasado</Badge>
                        ) : (
                          <Badge>Emprestado</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                      <span>Empréstimo: {loan.loanDate}</span>
                      <span>Devolução prevista: {loan.dueDate}</span>
                      {loan.returnDate && (
                        <span>Devolvido em: {loan.returnDate}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center">
              <p className="text-muted-foreground">
                Nenhuma movimentação registrada ainda.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
