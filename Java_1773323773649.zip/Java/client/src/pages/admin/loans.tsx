import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, CheckCircle2, Search } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLoanSchema, type Book, type User, type Loan } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { z } from "zod";

interface LoanWithDetails extends Loan {
  book: Book;
  user: User;
}

const loanFormSchema = insertLoanSchema.extend({
  loanDate: z.string(),
  dueDate: z.string(),
});

type LoanFormData = z.infer<typeof loanFormSchema>;

export default function LoansManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: loans, isLoading } = useQuery<LoanWithDetails[]>({
    queryKey: ["/api/admin/loans"],
  });

  const { data: books } = useQuery<Book[]>({
    queryKey: ["/api/admin/books"],
  });

  const { data: students } = useQuery<User[]>({
    queryKey: ["/api/admin/students"],
  });

  const form = useForm<LoanFormData>({
    resolver: zodResolver(loanFormSchema),
    defaultValues: {
      bookId: "",
      userId: "",
      loanDate: format(new Date(), "yyyy-MM-dd"),
      dueDate: format(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), "yyyy-MM-dd"),
      status: "active",
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: LoanFormData) => {
      await apiRequest("POST", "/api/admin/loans", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Empréstimo registrado com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Fazendo login novamente...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: error.message || "Não foi possível registrar o empréstimo.",
        variant: "destructive",
      });
    },
  });

  const returnMutation = useMutation({
    mutationFn: async (loanId: string) => {
      await apiRequest("PATCH", `/api/admin/loans/${loanId}/return`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Sucesso",
        description: "Devolução registrada com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Fazendo login novamente...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Não foi possível registrar a devolução.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: LoanFormData) => {
    createMutation.mutate(data);
  };

  const filteredLoans = loans?.filter(
    (loan) =>
      loan.book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loan.user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loan.user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      loan.user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (loan: LoanWithDetails) => {
    if (loan.status === "returned") {
      return <Badge variant="secondary">Devolvido</Badge>;
    }
    if (loan.status === "overdue") {
      return <Badge variant="destructive">Atrasado</Badge>;
    }
    return <Badge>Ativo</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <h1 className="text-3xl font-semibold">Gerenciamento de Empréstimos</h1>
        <Button onClick={() => setIsDialogOpen(true)} data-testid="button-add-loan">
          <Plus className="h-4 w-4 mr-2" />
          Registrar Empréstimo
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Buscar Empréstimos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por livro ou aluno..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-loans"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredLoans && filteredLoans.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Livro</TableHead>
                  <TableHead>Aluno</TableHead>
                  <TableHead>Data Empréstimo</TableHead>
                  <TableHead>Data Devolução</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLoans.map((loan) => (
                  <TableRow key={loan.id} data-testid={`row-loan-${loan.id}`}>
                    <TableCell className="font-medium">{loan.book.title}</TableCell>
                    <TableCell>
                      {loan.user.firstName || loan.user.email}
                    </TableCell>
                    <TableCell>{loan.loanDate}</TableCell>
                    <TableCell>{loan.dueDate}</TableCell>
                    <TableCell>{getStatusBadge(loan)}</TableCell>
                    <TableCell className="text-right">
                      {loan.status === "active" || loan.status === "overdue" ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => returnMutation.mutate(loan.id)}
                          data-testid={`button-return-${loan.id}`}
                        >
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Registrar Devolução
                        </Button>
                      ) : (
                        <span className="text-sm text-muted-foreground">
                          Devolvido em {loan.returnDate}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="p-12 text-center">
              <p className="text-muted-foreground">
                {searchTerm ? "Nenhum empréstimo encontrado." : "Nenhum empréstimo registrado ainda."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Registrar Empréstimo</DialogTitle>
            <DialogDescription>
              Preencha os dados do empréstimo abaixo
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="bookId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Livro</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-book">
                          <SelectValue placeholder="Selecione um livro" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {books?.filter(b => b.availableQuantity > 0).map((book) => (
                          <SelectItem key={book.id} value={book.id}>
                            {book.title} - {book.author}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Aluno</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-student">
                          <SelectValue placeholder="Selecione um aluno" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {students?.map((student) => (
                          <SelectItem key={student.id} value={student.id}>
                            {student.firstName || student.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="loanDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data do Empréstimo</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-loan-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data de Devolução</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-due-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={2} data-testid="input-loan-notes" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  data-testid="button-cancel"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  data-testid="button-submit-loan"
                >
                  {createMutation.isPending ? "Salvando..." : "Registrar"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
