import { useQuery } from "@tanstack/react-query";
import { BookOpen, Users, TrendingUp, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardStats {
  totalBooks: number;
  availableBooks: number;
  activeLoans: number;
  overdueLoans: number;
  totalReservations: number;
  totalStudents: number;
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/stats"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4 rounded" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Total de Livros",
      value: stats?.totalBooks || 0,
      description: `${stats?.availableBooks || 0} disponíveis`,
      icon: BookOpen,
      testId: "stat-total-books",
    },
    {
      title: "Empréstimos Ativos",
      value: stats?.activeLoans || 0,
      description: "Livros emprestados",
      icon: Users,
      testId: "stat-active-loans",
    },
    {
      title: "Reservas Pendentes",
      value: stats?.totalReservations || 0,
      description: "Aguardando disponibilidade",
      icon: TrendingUp,
      testId: "stat-reservations",
    },
    {
      title: "Empréstimos Atrasados",
      value: stats?.overdueLoans || 0,
      description: "Necessitam cobrança",
      icon: AlertCircle,
      testId: "stat-overdue",
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid={stat.testId}>
                {stat.value}
              </div>
              <p className="text-xs text-muted-foreground">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bem-vindo ao Painel Administrativo</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Use o menu lateral para navegar entre as diferentes seções do
            sistema de gerenciamento da biblioteca.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
