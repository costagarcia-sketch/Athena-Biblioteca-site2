import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { StudentHeader } from "@/components/student-header";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import AdminDashboard from "@/pages/admin/dashboard";
import BooksManagement from "@/pages/admin/books";
import LoansManagement from "@/pages/admin/loans";
import Movements from "@/pages/admin/movements";
import Charges from "@/pages/admin/charges";
import Catalog from "@/pages/student/catalog";
import MyReservations from "@/pages/student/my-reservations";
import MyLoans from "@/pages/student/my-loans";

function Router() {
  const { isAuthenticated, isLoading, isAdmin } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route component={Landing} />
      </Switch>
    );
  }

  if (isAdmin) {
    const style = {
      "--sidebar-width": "20rem",
      "--sidebar-width-icon": "4rem",
    };

    return (
      <SidebarProvider style={style as React.CSSProperties}>
        <div className="flex h-screen w-full">
          <AppSidebar />
          <div className="flex flex-col flex-1 overflow-hidden">
            <header className="flex items-center justify-between p-4 border-b">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
            </header>
            <main className="flex-1 overflow-y-auto p-6">
              <Switch>
                <Route path="/" component={AdminDashboard} />
                <Route path="/admin" component={AdminDashboard} />
                <Route path="/admin/books" component={BooksManagement} />
                <Route path="/admin/loans" component={LoansManagement} />
                <Route path="/admin/movements" component={Movements} />
                <Route path="/admin/charges" component={Charges} />
                <Route component={NotFound} />
              </Switch>
            </main>
          </div>
        </div>
      </SidebarProvider>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <StudentHeader />
      <main className="flex-1 container mx-auto px-4 md:px-8 py-6">
        <Switch>
          <Route path="/" component={Catalog} />
          <Route path="/catalog" component={Catalog} />
          <Route path="/my-reservations" component={MyReservations} />
          <Route path="/my-loans" component={MyLoans} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
