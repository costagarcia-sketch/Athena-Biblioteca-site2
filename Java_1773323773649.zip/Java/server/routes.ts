import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isAdmin } from "./replitAuth";
import {
  insertBookSchema,
  insertLoanSchema,
  insertReservationSchema,
  insertReviewSchema,
  books,
  users,
  reviews as reviewsTable,
} from "@shared/schema";
import { db } from "./db";
import { eq, sql, count } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.checkOverdueLoans();

      const allBooks = await storage.getAllBooks();
      const allLoans = await storage.getAllLoans();
      const students = await storage.getUsersByRole("student");

      const totalBooks = allBooks.length;
      const availableBooks = allBooks.filter(b => b.availableQuantity > 0).length;
      const activeLoans = allLoans.filter(l => l.status === "active" || l.status === "overdue").length;
      const overdueLoans = allLoans.filter(l => l.status === "overdue").length;

      // Get pending reservations count
      const { reservations: reservationsTable } = await import("@shared/schema");
      const reservationsCount = await db
        .select({ count: count() })
        .from(reservationsTable)
        .where(eq(reservationsTable.status, "pending"));

      res.json({
        totalBooks,
        availableBooks,
        activeLoans,
        overdueLoans,
        totalReservations: reservationsCount[0]?.count || 0,
        totalStudents: students.length,
      });
    } catch (error: any) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  app.get("/api/admin/books", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const allBooks = await storage.getAllBooks();
      res.json(allBooks);
    } catch (error: any) {
      console.error("Error fetching books:", error);
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.post("/api/admin/books", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validatedData = insertBookSchema.parse(req.body);
      const book = await storage.createBook(validatedData);
      res.json(book);
    } catch (error: any) {
      console.error("Error creating book:", error);
      res.status(400).json({ message: error.message || "Failed to create book" });
    }
  });

  app.patch("/api/admin/books/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertBookSchema.partial().parse(req.body);
      const book = await storage.updateBook(id, validatedData);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.json(book);
    } catch (error: any) {
      console.error("Error updating book:", error);
      res.status(400).json({ message: error.message || "Failed to update book" });
    }
  });

  app.delete("/api/admin/books/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteBook(id);
      res.json({ message: "Book deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting book:", error);
      res.status(500).json({ message: "Failed to delete book" });
    }
  });

  app.get("/api/admin/loans", isAuthenticated, isAdmin, async (req, res) => {
    try {
      await storage.checkOverdueLoans();
      const allLoans = await storage.getAllLoans();
      res.json(allLoans);
    } catch (error: any) {
      console.error("Error fetching loans:", error);
      res.status(500).json({ message: "Failed to fetch loans" });
    }
  });

  app.post("/api/admin/loans", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validatedData = insertLoanSchema.parse(req.body);

      const book = await storage.getBook(validatedData.bookId);
      if (!book || book.availableQuantity < 1) {
        return res.status(400).json({ message: "Book is not available" });
      }

      const loan = await storage.createLoan(validatedData);
      await storage.updateBookAvailability(validatedData.bookId, -1);

      res.json(loan);
    } catch (error: any) {
      console.error("Error creating loan:", error);
      res.status(400).json({ message: error.message || "Failed to create loan" });
    }
  });

  app.patch("/api/admin/loans/:id/return", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const allLoans = await storage.getAllLoans();
      const loanData = allLoans.find(l => l.id === id);

      if (!loanData) {
        return res.status(404).json({ message: "Loan not found" });
      }

      if (loanData.status === "returned") {
        return res.status(400).json({ message: "Loan already returned" });
      }

      const today = new Date().toISOString().split("T")[0];
      const loan = await storage.updateLoanStatus(id, "returned", today);
      await storage.updateBookAvailability(loanData.bookId, 1);

      res.json(loan);
    } catch (error: any) {
      console.error("Error returning loan:", error);
      res.status(500).json({ message: "Failed to return loan" });
    }
  });

  app.get("/api/admin/students", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const students = await storage.getUsersByRole("student");
      res.json(students);
    } catch (error: any) {
      console.error("Error fetching students:", error);
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  // Student routes
  app.get("/api/books", isAuthenticated, async (req, res) => {
    try {
      const allBooks = await storage.getAllBooks();

      const booksWithReviews = await Promise.all(
        allBooks.map(async (book) => {
          const reviewsData = await db
            .select({
              id: reviewsTable.id,
              bookId: reviewsTable.bookId,
              userId: reviewsTable.userId,
              rating: reviewsTable.rating,
              comment: reviewsTable.comment,
              createdAt: reviewsTable.createdAt,
              updatedAt: reviewsTable.updatedAt,
              user: users,
            })
            .from(reviewsTable)
            .leftJoin(users, eq(reviewsTable.userId, users.id))
            .where(eq(reviewsTable.bookId, book.id));

          const averageRating = reviewsData.length > 0
            ? reviewsData.reduce((sum, r) => sum + r.rating, 0) / reviewsData.length
            : 0;

          return {
            ...book,
            reviews: reviewsData,
            averageRating,
          };
        })
      );

      res.json(booksWithReviews);
    } catch (error: any) {
      console.error("Error fetching books:", error);
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.get("/api/loans", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.checkOverdueLoans();
      const userLoans = await storage.getLoansByUser(userId);
      res.json(userLoans);
    } catch (error: any) {
      console.error("Error fetching loans:", error);
      res.status(500).json({ message: "Failed to fetch loans" });
    }
  });

  app.get("/api/reservations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userReservations = await storage.getReservationsByUser(userId);
      res.json(userReservations);
    } catch (error: any) {
      console.error("Error fetching reservations:", error);
      res.status(500).json({ message: "Failed to fetch reservations" });
    }
  });

  app.post("/api/reservations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.body;

      const book = await storage.getBook(bookId);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      if (book.availableQuantity > 0) {
        return res.status(400).json({ message: "Book is available, no need to reserve" });
      }

      const today = new Date().toISOString().split("T")[0];
      const reservation = await storage.createReservation({
        bookId,
        userId,
        reservationDate: today,
        status: "pending",
      });

      res.json(reservation);
    } catch (error: any) {
      console.error("Error creating reservation:", error);
      res.status(400).json({ message: error.message || "Failed to create reservation" });
    }
  });

  app.delete("/api/reservations/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;

      const userReservations = await storage.getReservationsByUser(userId);
      const reservation = userReservations.find(r => r.id === id);

      if (!reservation) {
        return res.status(404).json({ message: "Reservation not found" });
      }

      await storage.deleteReservation(id);
      res.json({ message: "Reservation cancelled successfully" });
    } catch (error: any) {
      console.error("Error deleting reservation:", error);
      res.status(500).json({ message: "Failed to delete reservation" });
    }
  });

  app.post("/api/reviews", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertReviewSchema.parse({
        ...req.body,
        userId,
      });

      const review = await storage.createReview(validatedData);
      res.json(review);
    } catch (error: any) {
      console.error("Error creating review:", error);
      res.status(400).json({ message: error.message || "Failed to create review" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
