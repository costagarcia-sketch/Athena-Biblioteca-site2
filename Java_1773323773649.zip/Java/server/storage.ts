import {
  users,
  books,
  loans,
  reservations,
  reviews,
  type User,
  type UpsertUser,
  type Book,
  type InsertBook,
  type Loan,
  type InsertLoan,
  type Reservation,
  type InsertReservation,
  type Review,
  type InsertReview,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;

  // Book operations
  getAllBooks(): Promise<Book[]>;
  getBook(id: string): Promise<Book | undefined>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: string, book: Partial<InsertBook>): Promise<Book | undefined>;
  deleteBook(id: string): Promise<void>;
  updateBookAvailability(bookId: string, delta: number): Promise<void>;

  // Loan operations
  getAllLoans(): Promise<any[]>;
  getLoansByUser(userId: string): Promise<any[]>;
  createLoan(loan: InsertLoan): Promise<Loan>;
  updateLoanStatus(id: string, status: string, returnDate?: string): Promise<Loan | undefined>;
  checkOverdueLoans(): Promise<void>;

  // Reservation operations
  getReservationsByUser(userId: string): Promise<any[]>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
  deleteReservation(id: string): Promise<void>;

  // Review operations
  createReview(review: InsertReview): Promise<Review>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  // Book operations
  async getAllBooks(): Promise<Book[]> {
    return await db.select().from(books).orderBy(desc(books.createdAt));
  }

  async getBook(id: string): Promise<Book | undefined> {
    const [book] = await db.select().from(books).where(eq(books.id, id));
    return book;
  }

  async createBook(bookData: InsertBook): Promise<Book> {
    const [book] = await db.insert(books).values(bookData).returning();
    return book;
  }

  async updateBook(id: string, bookData: Partial<InsertBook>): Promise<Book | undefined> {
    const [book] = await db
      .update(books)
      .set({ ...bookData, updatedAt: new Date() })
      .where(eq(books.id, id))
      .returning();
    return book;
  }

  async deleteBook(id: string): Promise<void> {
    await db.delete(books).where(eq(books.id, id));
  }

  async updateBookAvailability(bookId: string, delta: number): Promise<void> {
    await db
      .update(books)
      .set({
        availableQuantity: sql`${books.availableQuantity} + ${delta}`,
        updatedAt: new Date(),
      })
      .where(eq(books.id, bookId));
  }

  // Loan operations
  async getAllLoans(): Promise<any[]> {
    return await db
      .select({
        id: loans.id,
        bookId: loans.bookId,
        userId: loans.userId,
        loanDate: loans.loanDate,
        dueDate: loans.dueDate,
        returnDate: loans.returnDate,
        status: loans.status,
        notes: loans.notes,
        createdAt: loans.createdAt,
        updatedAt: loans.updatedAt,
        book: books,
        user: users,
      })
      .from(loans)
      .leftJoin(books, eq(loans.bookId, books.id))
      .leftJoin(users, eq(loans.userId, users.id))
      .orderBy(desc(loans.createdAt));
  }

  async getLoansByUser(userId: string): Promise<any[]> {
    return await db
      .select({
        id: loans.id,
        bookId: loans.bookId,
        userId: loans.userId,
        loanDate: loans.loanDate,
        dueDate: loans.dueDate,
        returnDate: loans.returnDate,
        status: loans.status,
        notes: loans.notes,
        createdAt: loans.createdAt,
        updatedAt: loans.updatedAt,
        book: books,
      })
      .from(loans)
      .leftJoin(books, eq(loans.bookId, books.id))
      .where(eq(loans.userId, userId))
      .orderBy(desc(loans.createdAt));
  }

  async createLoan(loanData: InsertLoan): Promise<Loan> {
    const [loan] = await db.insert(loans).values(loanData).returning();
    return loan;
  }

  async updateLoanStatus(
    id: string,
    status: string,
    returnDate?: string
  ): Promise<Loan | undefined> {
    const updateData: any = { status, updatedAt: new Date() };
    if (returnDate) {
      updateData.returnDate = returnDate;
    }
    const [loan] = await db
      .update(loans)
      .set(updateData)
      .where(eq(loans.id, id))
      .returning();
    return loan;
  }

  async checkOverdueLoans(): Promise<void> {
    const today = new Date().toISOString().split("T")[0];
    await db
      .update(loans)
      .set({ status: "overdue", updatedAt: new Date() })
      .where(
        and(
          eq(loans.status, "active"),
          sql`${loans.dueDate} < ${today}`
        )
      );
  }

  // Reservation operations
  async getReservationsByUser(userId: string): Promise<any[]> {
    return await db
      .select({
        id: reservations.id,
        bookId: reservations.bookId,
        userId: reservations.userId,
        reservationDate: reservations.reservationDate,
        status: reservations.status,
        createdAt: reservations.createdAt,
        updatedAt: reservations.updatedAt,
        book: books,
      })
      .from(reservations)
      .leftJoin(books, eq(reservations.bookId, books.id))
      .where(eq(reservations.userId, userId))
      .orderBy(desc(reservations.createdAt));
  }

  async createReservation(reservationData: InsertReservation): Promise<Reservation> {
    const [reservation] = await db
      .insert(reservations)
      .values(reservationData)
      .returning();
    return reservation;
  }

  async deleteReservation(id: string): Promise<void> {
    await db.delete(reservations).where(eq(reservations.id, id));
  }

  // Review operations
  async createReview(reviewData: InsertReview): Promise<Review> {
    const [review] = await db.insert(reviews).values(reviewData).returning();
    return review;
  }
}

export const storage = new DatabaseStorage();
